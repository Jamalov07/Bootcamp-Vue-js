<template>
  <header></header>
</template>

<script>
export default {
    name:"Footer"
};
</script>

<style></style>

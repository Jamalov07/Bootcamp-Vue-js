<template>
  <div>Home Page</div>
</template>

<script>
export default {
  name: "Home",
};
</script>

<style></style>

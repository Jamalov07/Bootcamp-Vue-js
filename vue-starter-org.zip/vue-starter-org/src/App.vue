<template>
  <div class="bg-red-500 w-full">App</div>
</template>
<script>
export default {
  name: "App",
};
</script>
<style></style>
